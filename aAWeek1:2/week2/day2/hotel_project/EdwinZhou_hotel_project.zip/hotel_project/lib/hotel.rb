require_relative "room"

class Hotel
    def initialize(name, hash)
        @name = name
        @rooms = {}
        hash.each do |room_name, capacity|
            @rooms[room_name] = Room.new(capacity)
        end
    end

    def name
        @name.split.map(&:capitalize).join(" ")
        #{|word| word.capitalize} (&:capitalize)
    end

    def rooms
        @rooms
    end

    def room_exists?(room_name)
        rooms.has_key?(room_name)
    end

    def check_in(person, room_name)
        if !self.room_exists?(room_name)
            p "sorry, room does not exist"
            return
        end
        if @rooms[room_name].add_occupant(person) 
            print "check in successful"
        else
            print "sorry, room is full"
        end
    end

    def has_vacancy?
        #iterate thru hash
        #for each room in the hash, check if the room is full
        @rooms.each do |roomname,capacity|
           return true if !capacity.full?
        end
        false
    end

    def list_rooms
        @rooms.each {|name, capacity| puts name + " : " + capacity.available_space.to_s }
       
       #what it wands
        #-/Basement.*4\nAttic.*2\nUnder the Stairs.*0\n/
     
        #what we have
    #    +/Basement.*4
    #    +/Attic.*2
    #    +/Under the Stairs.*0
    end
end

